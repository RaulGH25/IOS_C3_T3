//
//  TableViewController.swift
//  Libros3
//
//  Created by Raul Guerra Hernandez on 1/4/17.
//  Copyright © 2017 Raul Guerra Hernandez. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController, ViewControllerBusquedaDelegate {
    
    
    // Titulo, Autores, Portada (urls)
    private var libros : Array<Array<String>> = Array<Array<String>>()
    
    @IBOutlet weak var buttonNuevoLibro: UIBarButtonItem!
    @IBOutlet var tableLibros: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Libros buscados"
    }
    
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.libros.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaReutilizable", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = self.libros[indexPath.row][0];
        
        return cell
    }
    


    
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if let barButton = sender as? UIBarButtonItem {
            if barButton == buttonNuevoLibro {
                //Do what you want
                let vistaBusqueda = segue.destination as! ViewControllerBusqueda
                vistaBusqueda.delegate = self
            }
        }else{        
            let vistaDetalle = segue.destination as! ViewControllerDetalle
            let ip = self.tableView.indexPathForSelectedRow
            vistaDetalle.libroDetalle = self.libros[ip!.row]
        }
    }
    
    
    
    
    
    func myVCDidFinish(controller:ViewControllerBusqueda, libroBuscado:Array<String>) {
        self.libros.append(libroBuscado)
        self.tableLibros.reloadData()
    }
    

    
    

}
