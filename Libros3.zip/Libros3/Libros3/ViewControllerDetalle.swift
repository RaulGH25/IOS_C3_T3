//
//  ViewControllerDetalle.swift
//  Libros3
//
//  Created by Raul Guerra Hernandez on 1/4/17.
//  Copyright © 2017 Raul Guerra Hernandez. All rights reserved.
//

import UIKit
import SystemConfiguration

class ViewControllerDetalle: UIViewController {
    
    
    @IBOutlet weak var textTitulo: UILabel!
    @IBOutlet weak var textAutores: UILabel!
    @IBOutlet weak var cuadroImagen: UIImageView!
    
    
    var libroDetalle : Array<String> = Array<String>()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //print("Autores : \(self.seguerVariable[1])")
        
        textTitulo.text = libroDetalle[0]
        textAutores.text = libroDetalle[1]
        showImageFromISBN()
    }



    
    
    func showImageFromISBN(){
        
        if isInternetAvailable() {
            
            let texto   : String = libroDetalle[2]
            if texto != "" { // If the text is "" means that there was no image for that ISBN
                
                let urls    : String = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + texto
                let url = NSURL(string : urls)
                let datos : NSData? = NSData(contentsOf: url! as URL)
                
                do {
                    let json = try JSONSerialization.jsonObject(with: datos! as Data, options: .mutableLeaves)
                    let dic1 = json as! NSDictionary
                    let dic2 = dic1["ISBN:" + texto] as! NSDictionary
                    
                    // ----- Mostrar portada -----
                    
                    let dicImagenes = dic2["cover"] as! NSDictionary
                    let img_urls = dicImagenes["medium"] as! String
                    let img_url = NSURL(string : img_urls)
                    let img_datos = NSData(contentsOf: img_url! as URL)
                    
                    if let imagen = UIImage(data: img_datos! as Data){
                        self.cuadroImagen.image = imagen
                    }
                } catch  {}
            }
        }
    }
    
    
    
    // Internet
    func isInternetAvailable() -> Bool
    {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }

}
